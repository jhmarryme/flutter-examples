package com.example.test_in_action;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
