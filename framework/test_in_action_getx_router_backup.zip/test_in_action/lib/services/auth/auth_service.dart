import 'package:get/get.dart';
import 'package:test_in_action/common/http/dio_utils.dart';
import 'package:test_in_action/common/http/request_helper.dart';
import 'package:test_in_action/models/auth/login_result_entity.dart';
import 'package:test_in_action/models/auth/token_entity.dart';
import 'package:test_in_action/services/storage/auth_repository.dart';
import 'package:test_in_action/utils/log_utils.dart';
import 'package:test_in_action/utils/other_utils.dart';

import 'auth_state.dart';

class AuthService extends GetxService {
  static AuthService get to => Get.find();

  final state = AuthState();

  late final AuthRepository authRepository;

  AuthService() {
    authRepository = AuthRepository();
  }

  String get getAccessToken {
    if (state.token.value.isBlank == false) {
      return state.token.value;
    }
    final accessTokenInCache = authRepository.getToken()?.accessToken;
    LogUtil.d("accessTokenInCache: $accessTokenInCache");
    state.token.value = accessTokenInCache.nullSafe;
    return accessTokenInCache.nullSafe;
  }

  String get getRefreshToken {
    if (state.token.value.isBlank == false) {
      return state.token.value;
    }
    return (authRepository.getToken()?.refreshToken).nullSafe;
  }

  bool get isLogin {
    return getAccessToken.isBlank == false;
  }

  /// 登陆
  Future<bool> login(String username, String password) async {
    final Map<String, String> params = <String, String>{};
    params['username'] = username;
    params['password'] = password;
    LoginResultEntity? user =
        await RequestHelper.requestNetwork<LoginResultEntity>(
      Method.post,
      params: params,
      url:
          "https://console-mock.apipost.cn/mock/e090c5f3-73d8-4738-b3d8-6beef69b00dc/v1/login?apipost_id=67aebd",
    );
    if (user == null || user.userId == null || user.token == null) {
      // TipsUtil.showToast("登陆失败");
      return false;
    }
    LogUtil.d('login result: ${user.toJson()}');
    saveLoginInfo(user);
    return true;
  }

  /// 清空缓存
  void logout() {
    state.token.value = "";
    state.isLoggedIn.value = false;
    authRepository.logout();
  }

  /// 保存登陆信息, 同步缓存
  void saveLoginInfo(LoginResultEntity user) {
    state.token.value = user.token!;
    state.userId.value = user.userId!;
    state.isLoggedIn.value = true;
    final tokenEntity = TokenEntity();
    tokenEntity.accessToken = state.token.value;
    authRepository.setLoginUserInfo(tokenEntity);
  }
}
