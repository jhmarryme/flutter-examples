import 'package:test_in_action/common/http/interceptor/logging_interceptor.dart';

class DefaultLoggingInterceptor extends LoggingInterceptor {}
