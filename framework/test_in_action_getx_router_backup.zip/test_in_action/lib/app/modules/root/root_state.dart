class RootState {
  RootState() {
    ///Initialize variables
  }
}
