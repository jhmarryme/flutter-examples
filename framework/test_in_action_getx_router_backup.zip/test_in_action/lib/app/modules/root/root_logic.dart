import 'package:get/get.dart';

import 'root_state.dart';

class RootLogic extends GetxController {
  final RootState state = RootState();
}
