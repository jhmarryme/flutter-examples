import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:sidebarx/sidebarx.dart';
import 'package:test_in_action/app/modules/home/index/home_logic.dart';
import 'package:test_in_action/common/styles/sidebarx_style.dart';

/// 主页
/// 适配页面保活
class RootViewLarge extends GetView<HomeLogic> {
  RootViewLarge({Key? key, required this.navigationShell}) : super(key: key);

  final StatefulNavigationShell navigationShell;

  @override
  Widget build(BuildContext context) {
    final logic = Get.find<HomeLogic>();
    SidebarXController sidebarxController = SidebarXController(
        selectedIndex: navigationShell.currentIndex, extended: false);
    return Row(
      children: [
        SidebarX(
          controller: sidebarxController,
          theme: SidebarxStyle.theme(),
          extendedTheme: SidebarxStyle.extendedTheme(),
          footerDivider: Column(
            children: [
              ElevatedButton(
                  onPressed: () => logic.logout(),
                  child: Icon(Icons.exit_to_app)),
              Divider(color: white.withOpacity(0.3), height: 1),
            ],
          ),
          headerBuilder: (context, extended) => SidebarxStyle.header(),
          items: [
            SidebarXItem(
                icon: Icons.home,
                label: 'page0',
                onTap: () => _onTap(context, 0)),
            SidebarXItem(
                icon: Icons.search,
                label: 'page1',
                onTap: () => _onTap(context, 1)),
            SidebarXItem(
                icon: Icons.people,
                label: 'page2',
                onTap: () => _onTap(context, 2)),
            SidebarXItem(
                icon: Icons.favorite,
                label: 'page3',
                onTap: () => _onTap(context, 3)),
          ],
        ),
        Expanded(child: navigationShell),
      ],
    );
  }

  void _onTap(BuildContext context, int index) {
    // When navigating to a new branch, it's recommended to use the goBranch
    // method, as doing so makes sure the last navigation state of the
    // Navigator for the branch is restored.
    navigationShell.goBranch(
      index,
      initialLocation: index == navigationShell.currentIndex,
    );
  }
}
