import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:test_in_action/app/routes/app_pages.dart';

class DashboardController extends GetxController {
  final now = DateTime.now().obs;
  final navigatorKeyId = "${Routes.dashboard}:navigator";

  @override
  void onReady() {
    super.onReady();
    Timer.periodic(
      const Duration(seconds: 1),
      (timer) {
        now.value = DateTime.now();
      },
    );
  }

  Route? onGenerateRoute(RouteSettings settings) {
    if (settings.name == Routes.dataGrid) {
      return GetPageRoute(
        settings: settings,
        page: AppPages.dataDataGridRoute.page,
        transition: Transition.rightToLeftWithFade,
        binding: AppPages.dataDataGridRoute.binding,
      );
    }
    // 这里应该返回404
    return GetPageRoute(
      settings: settings,
      page: AppPages.unknownRoute.page,
      binding: AppPages.unknownRoute.binding,
      transition: Transition.fadeIn,
    );
  }
}
