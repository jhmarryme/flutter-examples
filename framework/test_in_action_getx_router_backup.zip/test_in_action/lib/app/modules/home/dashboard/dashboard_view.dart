import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:test_in_action/app/modules/examples/data_grid/data_grid_paging/data_grid_paging_binding.dart';
import 'package:test_in_action/app/modules/examples/data_grid/data_grid_paging/data_grid_paging_view.dart';
import 'package:test_in_action/app/routes/app_pages.dart';

import 'dashboard_controller.dart';

class DashboardView extends GetView<DashboardController> {
  const DashboardView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Navigator(
        key: Get.nestedKey(controller.navigatorKeyId)?.navigatorKey,
        initialRoute: Routes.login,
        onGenerateRoute: controller.onGenerateRoute,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.keys[controller.navigatorKeyId]!.navigatorKey.currentState
              ?.pushNamed(Routes.dataGrid);
        },
      ),
    );
    return Scaffold(
      body: Center(
        child: GetBuilder<DashboardController>(
          builder: (controller) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('测试用', style: TextStyle(fontSize: 20)),
                Text('Time: ${controller.now.value.toString()}'),
              ],
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Get.to(
          () => DataGridPagingView(),
          bindings: [DataGridPagingBinding()],
          preventDuplicates: false,
        ),
      ),
    );
  }
}
