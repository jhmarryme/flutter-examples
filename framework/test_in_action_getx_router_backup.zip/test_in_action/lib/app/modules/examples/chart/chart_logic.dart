import 'package:get/get.dart';

class ChartLogic extends GetxController {}
