import 'package:easy_refresh/easy_refresh.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:test_in_action/app/components/my_refresh/my_easy_refresh/refresh_on_start/widget/base_get_page_logic.dart';
import 'package:test_in_action/app/components/my_refresh/my_easy_refresh/refresh_on_start/widget/refresh_status.dart';
import 'package:test_in_action/common/foo/test_user_entity.dart';
import 'package:test_in_action/common/http/http.dart';
import 'package:test_in_action/common/http/model/paging_data_entity.dart';
import 'package:test_in_action/common/http/request_helper.dart';

class RefreshController extends BaseGetPageLogic<TestUserEntity> {
  final now = DateTime.now().obs;
  ScrollController controller = ScrollController();

  /// 重写
  @override
  get scrollController => controller;

  @override
  void requestData(EasyRefreshController controller,
      {RefreshStatus refresh = RefreshStatus.first}) {
    final Map<String, dynamic> params = <String, dynamic>{};
    params['size'] = page;
    // 分页请求
    RequestHelper.requestPageNetwork<TestUserEntity>(
      Method.post,
      // queryParameters: params,
      params: params,
      showLoading: refresh == RefreshStatus.wheelDown,
      onSuccess: (data) {
        bool over = calcIsOver(data);
        onFinishRequest(controller, refresh, over, data?.records ?? []);
        update();
      },
      onError: (code, msg) {
        print("code: $code, msg: $msg");
      },
      url:
          "https://console-mock.apipost.cn/mock/e090c5f3-73d8-4738-b3d8-6beef69b00dc/v1/order/order",
    );
  }

  bool calcIsOver(PagingDataEntity<dynamic>? entity) {
    int? size = entity?.size;
    int? total = entity?.total;
    int? current = entity?.current;
    if (size == null || total == null || current == null) {
      return true;
    }
    double pages = total / size;
    return current >= pages.ceil();
  }
}
