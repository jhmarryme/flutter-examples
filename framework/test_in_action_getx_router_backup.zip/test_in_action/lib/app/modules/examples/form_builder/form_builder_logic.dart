import 'package:get/get.dart';

import 'form_builder_state.dart';

class FormBuilderLogic extends GetxController {
  final FormBuilderState state = FormBuilderState();
}
