import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:test_in_action/app/components/form_builder/default/default_form.dart';
import 'package:test_in_action/app/routes/app_pages.dart';

import 'form_builder_logic.dart';

class FormBuilderView extends StatelessWidget {
  const FormBuilderView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final logic = Get.find<FormBuilderLogic>();
    final state = Get.find<FormBuilderLogic>().state;

    return Scaffold(
      appBar: AppBar(
        leading: GestureDetector(
          onTap: () => Get.toNamed(Routes.home),
          child: const Icon(Icons.arrow_back),
        ),
      ),
      body: Center(
        child: Row(
          children: <Widget>[
            Spacer(),
            Expanded(
              child: DefaultForm(),
              flex: 2,
            ),
            Spacer(),
          ],
        ),
      ),
    );
  }
}
