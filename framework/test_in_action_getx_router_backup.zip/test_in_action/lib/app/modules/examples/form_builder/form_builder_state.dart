class FormBuilderState {
  FormBuilderState() {
    ///Initialize variables
  }
}
