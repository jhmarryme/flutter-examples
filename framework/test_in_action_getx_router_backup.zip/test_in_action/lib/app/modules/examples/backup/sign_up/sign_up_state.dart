class SignUpState {
  SignUpState() {
    ///Initialize variables
  }
}
