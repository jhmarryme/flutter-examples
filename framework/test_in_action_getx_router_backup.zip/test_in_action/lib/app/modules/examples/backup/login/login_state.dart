class LoginState {
  LoginState() {
    ///Initialize variables
  }
}
