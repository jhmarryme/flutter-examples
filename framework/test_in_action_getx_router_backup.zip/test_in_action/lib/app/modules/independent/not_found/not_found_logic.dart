import 'package:get/get.dart';

import 'not_found_state.dart';

class NotFoundLogic extends GetxController {
  final NotFoundState state = NotFoundState();
}
