class NotFoundState {
  NotFoundState() {
    ///Initialize variables
  }
}
