
class HttpApi{
  static const String users = 'users/simplezhli';
  static const String search = 'search/repositories';
  static const String subscriptions = 'users/simplezhli/subscriptions';
  static const String upload = 'uuc/upload-inco';
}
