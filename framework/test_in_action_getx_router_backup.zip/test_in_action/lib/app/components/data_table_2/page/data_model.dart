class DataModel {
  final String name;
  final int age;
  bool selected;

  DataModel({required this.name, required this.age, this.selected = false});
}
