import 'package:get/get.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:test_in_action/common/http/model/paging_data_entity.dart';

abstract class PageDataGridSource<T> extends DataGridSource {
  // 当前页数

  final page = 1.obs;
  final rowsPerPage = 5.obs;
  final total = 0.obs;
  final pageCount = 1.0.obs;
  final records = [].obs;

  final initial = false;

  @override
  Future<bool> handlePageChange(int oldPageIndex, int newPageIndex) async {
    // int startIndex = newPageIndex * rowsPerPage.value;
    // int endIndex = startIndex + rowsPerPage.value;
    // if (startIndex < records.length && endIndex <= records.length) {
    //   await Future.delayed(Duration(milliseconds: 2000));
    //   await onLoadPage(newPageIndex + 1);
    //   notifyListeners();
    // } else {
    //   records.clear();
    // }
    if (oldPageIndex != newPageIndex) {
      await onLoadPage(newPageIndex + 1);
    }
    return true;
  }

  onLoadMore() async {
    ++page.value;
    await requestData();
  }

  onLoadPage(int newPage) async {
    page.value = newPage;
    await requestData();
  }

  onLoadRefresh() async {
    page.value = 1;
    await requestData();
  }

  Future<void> requestData() async {}

  void buildDataGridRows();

  List<GridColumn> get columns;

  void onFinishRequest(PagingDataEntity<T>? pageData) {
    if (pageData != null) {
      rowsPerPage.value = pageData.size ?? 0;
      total.value = pageData.total ?? 0;
      var count = (total.value / rowsPerPage.value).ceilToDouble();
      pageCount.value = count == 0 ? 1 : count;
      records.clear();
      records.addAll(pageData.records ?? []);
      buildDataGridRows();
      notifyListeners();
    }
  }
}
