class SalesData {
  SalesData(this.xValue, this.yValue);

  final String xValue;
  final double yValue;
}
