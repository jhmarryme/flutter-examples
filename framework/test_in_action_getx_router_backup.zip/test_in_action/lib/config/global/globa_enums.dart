enum Language {
  en("en"),
  zh("zh"),
  ;

  final String value;

  const Language(this.value);
}
